using System.Net.Http.Json;
using KONSolutions.Shared.Common;
using KONSolutions.Shared.Models.Estandar;

namespace KONSolutions.Web.Services;

public class ConfiguracionGeneralService
{
    private readonly HttpClient _http;
    private readonly ErrorLogService _errorLog;
    private const string Ruta = "api/v1/estandar/configuracion-general";

    public ConfiguracionGeneralService(HttpClient http, ErrorLogService errorLog)
    { _http = http; _errorLog = errorLog; }

    public async Task<ConfiguracionGeneral?> GetCurrentAsync()
    {
        try
        {
            var r = await _http.GetFromJsonAsync<ApiResponse<List<ConfiguracionGeneral>>>(Ruta);
            return r?.Data?.FirstOrDefault();
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, "ConfiguracionGeneral", nameof(GetCurrentAsync)); return null; }
    }

    public async Task<bool> SaveAsync(ConfiguracionGeneral cfg)
    {
        try
        {
            var resp = await _http.PostAsJsonAsync(Ruta, cfg);
            return resp.IsSuccessStatusCode;
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, "ConfiguracionGeneral", nameof(SaveAsync)); return false; }
    }
}
