using System.Net.Http.Json;
using KONSolutions.Shared.Common;
using KONSolutions.Shared.Models.Estandar;

namespace KONSolutions.Web.Services;

/// <summary>Motivos (hijos de un TipoMotivo). Se cargan filtrados por COD_TIPO_MOTIVO.</summary>
public class MotivoService
{
    private readonly HttpClient _http;
    private readonly AccessLogService _accessLog;
    private readonly ErrorLogService _errorLog;

    public MotivoService(HttpClient http, AccessLogService accessLog, ErrorLogService errorLog)
    { _http = http; _accessLog = accessLog; _errorLog = errorLog; }

    public async Task<List<Motivo>> GetByTipoAsync(int codTipoMotivo)
    {
        try
        {
            var r = await _http.GetFromJsonAsync<ApiResponse<List<Motivo>>>(
                $"{ApiRoutes.Estandar.MotivosPorTipo}/{codTipoMotivo}");
            return r?.Data ?? new();
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, "Motivos", nameof(GetByTipoAsync)); return new(); }
    }

    public async Task<(bool ok, string msg)> GuardarAsync(MotivoDto dto)
        => await Escribir(() => _http.PostAsJsonAsync(ApiRoutes.Estandar.Motivos, dto));

    public async Task<(bool ok, string msg)> EliminarAsync(int codTipoMotivo, int codMotivo)
        => await Escribir(() => _http.DeleteAsync($"{ApiRoutes.Estandar.Motivos}/{codTipoMotivo}/{codMotivo}"));

    private async Task<(bool, string)> Escribir(Func<Task<HttpResponseMessage>> accion)
    {
        try
        {
            var resp = await accion();
            var raw = await resp.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(raw))
                return resp.IsSuccessStatusCode ? (true, "Operación realizada.") : (false, $"Error (HTTP {(int)resp.StatusCode}).");
            try
            {
                var r = System.Text.Json.JsonSerializer.Deserialize<ApiResponse<WriteResult>>(raw,
                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (r is not null)
                    return r.Success ? (true, string.IsNullOrWhiteSpace(r.Message) ? "Operación realizada." : r.Message)
                                     : (false, string.IsNullOrWhiteSpace(r.Message) ? "Operación rechazada." : r.Message);
            }
            catch (System.Text.Json.JsonException) { if (resp.IsSuccessStatusCode) return (true, "Operación realizada."); }
            return resp.IsSuccessStatusCode ? (true, "Operación realizada.") : (false, $"Error (HTTP {(int)resp.StatusCode}).");
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, "Motivos", "ESCRIBIR"); return (false, ex.Message); }
    }
}
