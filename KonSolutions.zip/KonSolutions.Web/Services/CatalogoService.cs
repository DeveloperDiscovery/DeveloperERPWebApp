using System.Net.Http.Json;
using KONSolutions.Shared.Common;

namespace KONSolutions.Web.Services;

/// <summary>
/// Servicio CRUD genérico para catálogos simples (lectura, combobox, guardar, eliminar).
/// Reutilizable por Perfiles, Roles, ComplejidadPassword, Aplicaciones.
/// TEntidad = modelo de lectura, TDto = modelo de escritura.
/// </summary>
public class CatalogoService<TEntidad, TDto>
{
    private readonly HttpClient _http;
    private readonly AccessLogService _accessLog;
    private readonly ErrorLogService _errorLog;
    private readonly string _ruta;
    private readonly string _modulo;

    public CatalogoService(HttpClient http, AccessLogService accessLog, ErrorLogService errorLog,
        string ruta, string modulo)
    { _http = http; _accessLog = accessLog; _errorLog = errorLog; _ruta = ruta; _modulo = modulo; }

    public async Task<List<TEntidad>> GetAllAsync()
    {
        try
        {
            await _accessLog.LogEventoAsync(_modulo, _modulo, "SHOWALL");
            var r = await _http.GetFromJsonAsync<ApiResponse<List<TEntidad>>>(_ruta);
            return r?.Data ?? new();
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, _modulo, nameof(GetAllAsync)); return new(); }
    }

    /// <summary>Búsqueda usando el endpoint /search (SP _SEARCH).</summary>
    public async Task<List<TEntidad>> SearchAsync(string termino)
    {
        if (string.IsNullOrWhiteSpace(termino)) return await GetAllAsync();
        try
        {
            await _accessLog.LogEventoAsync(_modulo, _modulo, "SEARCH", new { termino });
            var r = await _http.GetFromJsonAsync<ApiResponse<List<TEntidad>>>(
                $"{_ruta}/search?search={Uri.EscapeDataString(termino)}");
            return r?.Data ?? new();
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, _modulo, nameof(SearchAsync)); return new(); }
    }

    public async Task<List<ComboboxItem>> GetComboboxAsync()
    {
        try
        {
            var r = await _http.GetFromJsonAsync<ApiResponse<List<ComboboxItem>>>($"{_ruta}/combobox");
            return r?.Data ?? new();
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, _modulo, nameof(GetComboboxAsync)); return new(); }
    }

    public async Task<TEntidad?> GetByIdAsync(string id)
    {
        try
        {
            var r = await _http.GetFromJsonAsync<ApiResponse<TEntidad>>($"{_ruta}/{Uri.EscapeDataString(id)}");
            return r is not null ? r.Data : default;
        }
        catch (Exception ex) { await _errorLog.LogAsync(ex, _modulo, nameof(GetByIdAsync), id); return default; }
    }

    public async Task<(bool ok, string msg)> GuardarAsync(TDto dto)
        => await Escribir(() => _http.PostAsJsonAsync(_ruta, dto), "GUARDAR");

    public async Task<(bool ok, string msg)> EliminarAsync(string id)
        => await Escribir(() => _http.DeleteAsync($"{_ruta}/{Uri.EscapeDataString(id)}"), "DELETE", id);

    private async Task<(bool, string)> Escribir(Func<Task<HttpResponseMessage>> accion, string evento, string? id = null)
    {
        try
        {
            await _accessLog.LogEventoAsync(_modulo, _modulo, evento, id is null ? null : new { id });
            var resp = await accion();
            var raw = await resp.Content.ReadAsStringAsync();

            if (string.IsNullOrWhiteSpace(raw))
                return resp.IsSuccessStatusCode ? (true, "Operación realizada.") : (false, $"Error (HTTP {(int)resp.StatusCode}).");

            try
            {
                var r = System.Text.Json.JsonSerializer.Deserialize<ApiResponse<WriteResult>>(raw,
                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (r is not null)
                    return r.Success ? (true, string.IsNullOrWhiteSpace(r.Message) ? "Operación realizada." : r.Message)
                                     : (false, string.IsNullOrWhiteSpace(r.Message) ? "Operación rechazada." : r.Message);
            }
            catch (System.Text.Json.JsonException)
            {
                if (resp.IsSuccessStatusCode) return (true, "Operación realizada.");
            }
            return resp.IsSuccessStatusCode ? (true, "Operación realizada.") : (false, $"Error (HTTP {(int)resp.StatusCode}).");
        }
        catch (Exception ex)
        {
            await _errorLog.LogAsync(ex, _modulo, evento);
            return (false, ex.Message);
        }
    }
}
