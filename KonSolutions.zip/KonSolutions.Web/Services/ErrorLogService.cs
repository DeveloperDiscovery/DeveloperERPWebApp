using Blazored.LocalStorage;
using System.Net.Http.Json;

namespace KONSolutions.Web.Services;

/// <summary>
/// Log de errores del frontend. Solo envía a la API si hay sesión activa.
/// </summary>
public class ErrorLogService
{
    private readonly HttpClient           _http;
    private readonly ILocalStorageService _localStorage;

    public ErrorLogService(HttpClient http, ILocalStorageService localStorage)
    {
        _http         = http;
        _localStorage = localStorage;
    }

    public async Task LogAsync(Exception ex, string pagina, string metodo, string? parametros = null)
    {
        var entry = new
        {
            Programa   = "KONSolutions.Web",
            Clase      = pagina,
            Metodo     = metodo,
            TipoError  = "BLAZOR",
            Mensaje    = ex.Message,
            Detalle    = ex.ToString(),
            Parametros = parametros ?? string.Empty,
            Fecha      = DateTime.Now
        };

        Console.Error.WriteLine($"[ERROR] {pagina}.{metodo}: {ex.Message}");

        try
        {
            var sesion = await _localStorage.GetItemAsync<object>("usuarioSesion");
            if (sesion is null) return;
            await _http.PostAsJsonAsync(ApiRoutes.Developer.ErrorLog, entry);
        }
        catch { }
    }

    /// <summary>
    /// Registra un mensaje de traza informacional (sin excepción).
    /// Usa TipoError = "TRACE" para distinguirlo de errores reales.
    /// Escribe también en la consola del navegador para seguimiento en DevTools.
    /// </summary>
    public async Task TraceAsync(string mensaje, string detalle = "")
    {
        var now = DateTime.Now;
        Console.WriteLine($"[TRACE] {now:yyyy-MM-dd HH:mm:ss.fff} — {mensaje}");

        try
        {
            var sesion = await _localStorage.GetItemAsync<object>("usuarioSesion");
            if (sesion is null)
            {
                // Aún sin sesión (ej. durante el login): solo consola
                return;
            }

            var entry = new
            {
                Programa   = "KONSolutions.Web",
                Clase      = "MainLayout",
                Metodo     = mensaje,
                TipoError  = "TRACE",
                Mensaje    = mensaje,
                Detalle    = detalle,
                Parametros = string.Empty,
                Fecha      = now
            };
            await _http.PostAsJsonAsync(ApiRoutes.Developer.ErrorLog, entry);
        }
        catch { }
    }
}
