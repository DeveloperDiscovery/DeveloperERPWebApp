using System.Net.Http.Headers;
using Blazored.LocalStorage;
using Microsoft.JSInterop;

namespace KONSolutions.Web.Services;

/// <summary>
/// Añade el token JWT a cada request saliente y muestra el spinner de cursor
/// (estilo iOS, transparente) mientras dura cualquier carga o guardado.
/// </summary>
public class JwtMessageHandler : DelegatingHandler
{
    private readonly ILocalStorageService _localStorage;
    private readonly IJSRuntime _js;

    /// <summary>
    /// MainLayout la pone en true mientras dura el splash inicial (configuración + menú)
    /// y en false apenas termina. Con esto en true, este handler NO muestra su propio
    /// spinner global por cada request — evita que compita visualmente con el círculo
    /// de porcentaje del splash, que ya es el único indicador de carga que debe verse
    /// en ese momento.
    /// </summary>
    public static bool SplashActivo { get; set; }

    /// <summary>
    /// Clave de HttpRequestOptions para marcar requests silenciosos (sondeos en segundo
    /// plano como el control de cambios) que NO deben disparar el spinner global — evita
    /// el parpadeo del anillo+logo cada vez que el timer de sondeo dispara su GET.
    /// </summary>
    public static readonly HttpRequestOptionsKey<bool> SinSpinnerKey = new("SinSpinner");

    /// <summary>
    /// ControlCambiosClientService la pone en true mientras ejecuta los callbacks de
    /// refresco de las pantallas suscritas (cuando el sondeo detecta un cambio real) —
    /// esos Load() hacen sus propios requests normales, y sin este flag encenderían el
    /// spinner global igual. Con esto, el proceso de Control de Cambios queda 100% silencioso.
    /// </summary>
    public static bool ControlCambiosActivo { get; set; }

    public JwtMessageHandler(ILocalStorageService localStorage, IJSRuntime js)
    { _localStorage = localStorage; _js = js; }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        string? token = null;
        try { token = await _localStorage.GetItemAsync<string>("authToken"); } catch { }
        if (!string.IsNullOrWhiteSpace(token))
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var sinSpinner = request.Options.TryGetValue(SinSpinnerKey, out var s) && s;
        var mostrarSpinner = !SplashActivo && !sinSpinner && !ControlCambiosActivo;
        if (mostrarSpinner) { try { await _js.InvokeVoidAsync("cursorBusy.show"); } catch { } }
        try
        {
            return await base.SendAsync(request, cancellationToken);
        }
        finally
        {
            if (mostrarSpinner) { try { await _js.InvokeVoidAsync("cursorBusy.hide"); } catch { } }
        }
    }
}
