using EstandarEntidades      = KONSolutions.Web.Pages.Estandar.Entidades;
using EstandarMonedas        = KONSolutions.Web.Pages.Estandar.Monedas;
using EstandarMonedasTC      = KONSolutions.Web.Pages.Estandar.MonedasTipoCambio;
using KONSolutions.Web.Pages.Externo;
using KONSolutions.Web.Pages.Seguridad;
using KONSolutions.Web.Pages.Estandar;
using EstandarSexos = KONSolutions.Web.Pages.Estandar.Sexos;
using EstandarUbigeos = KONSolutions.Web.Pages.Estandar.Ubigeos;
using EstandarPaises = KONSolutions.Web.Pages.Estandar.Paises;
using KONSolutions.Web.Pages;
using KONSolutions.Web.Pages.Developer;
using MenuCircularPage = KONSolutions.Web.Pages.MenuCircularPage;
using KONSolutions.Web.Pages.Seguridad.Treeview;
using KONSolutions.Web.Pages.Ingenieria;
using KONSolutions.Web.Pages.Comercial;
using KONSolutions.Web.Pages.Controlcalidad;
using KONSolutions.Web.Pages.Entorno;
using MudBlazor;

namespace KONSolutions.Web.Services;

/// <summary>
/// Registro central de pantallas que pueden abrirse como pestañas.
/// Mapea una ruta a su tipo de componente, título e icono.
/// </summary>
public static class WorkspaceRegistry
{
    public record PantallaInfo(string Ruta, string Titulo, string Icono, Type ComponentType);

    public static readonly List<PantallaInfo> Pantallas = new()
    {
        // Seguridad
        new("/seguridad/usuarios",            "Usuarios",              Icons.Material.Filled.People,              typeof(Usuarios)),
        new("/seguridad/perfiles",            "Perfiles",              Icons.Material.Filled.Badge,               typeof(Perfiles)),
        new("/seguridad/roles",               "Roles",                 Icons.Material.Filled.AdminPanelSettings,  typeof(Roles)),
        new("/seguridad/aplicaciones",        "Aplicaciones",          Icons.Material.Filled.Apps,                typeof(Aplicaciones)),
        new("/seguridad/opciones-aplicaciones",          "Opciones Aplicaciones", Icons.Material.Filled.AccountTree, typeof(KONSolutions.Web.Pages.Seguridad.Treeview.OpcionesAplicaciones)),
        new("/seguridad/treeview/opciones-aplicaciones", "Opciones Aplicaciones", Icons.Material.Filled.AccountTree, typeof(KONSolutions.Web.Pages.Seguridad.Treeview.OpcionesAplicaciones)),
        new("/seguridad/opciones-menu",                 "Opciones Menú",         Icons.Material.Filled.Interests,   typeof(OpcionesMenu)),
        new("/seguridad/treeview/opciones-menu",        "Opciones Menú",         Icons.Material.Filled.Interests,   typeof(OpcionesMenu)),
        new("/seguridad/complejidad-password","Complejidad contraseña",Icons.Material.Filled.Password,            typeof(ComplejidadPassword)),
        new("/seguridad/botones-estandar",    "Botones Estándar",      Icons.Material.Filled.SmartButton,         typeof(BotonesEstandar)),
        new("/seguridad/asignacion-roles",    "Asignación de Roles",   Icons.Material.Filled.GroupAdd,            typeof(AsignacionRoles)),
        new("/seguridad/asignacion-opciones-roles", "Asignación de Opciones de Menú a Roles", Icons.Material.Filled.AccountTree, typeof(AsignacionOpcionesRoles)),
        new("/seguridad/tipos-opciones",      "Tipos de Opciones",     Icons.Material.Filled.AccountTree,         typeof(KONSolutions.Web.Pages.Seguridad.TiposOpciones)),
        // Estándar
        new("/estandar/configuracion-general",    "Configuración General",  Icons.Material.Filled.Tune,                typeof(ConfiguracionGeneral)),
        new("/configuracion-general",             "Configuración General",  Icons.Material.Filled.Tune,                typeof(ConfiguracionGeneral)),
        new("/estandar/configuracion-usuario",    "Configuración de Usuario", Icons.Material.Filled.Person,             typeof(ConfiguracionUsuario)),
        new("/configuracion-usuario",              "Configuración de Usuario", Icons.Material.Filled.Person,             typeof(ConfiguracionUsuario)),
        new("/estandar/tipos-estados",        "Tipos de Estados",      Icons.Material.Filled.Label,               typeof(TiposEstados)),
        new("/estandar/estados-estandar",     "Estados Estándar",      Icons.Material.Filled.Style,               typeof(EstadosEstandar)),
        new("/estandar/tipos-motivos",          "Tipos de Motivos",              Icons.Material.Filled.Category,         typeof(TiposMotivos)),
        new("/estandar/tipos-menu-opciones",    "Tipos de Menú de Opciones",     Icons.Material.Filled.Category,         typeof(KONSolutions.Web.Pages.Estandar.TiposMenuOpciones)),
        new("/entorno/tipos-notificaciones",    "Tipos de Notificaciones",       Icons.Material.Filled.Notifications,    typeof(TiposNotificaciones)),
        new("/entorno/servidores",              "Servidores",                    Icons.Material.Filled.Dns,              typeof(Servidores)),
        new("/entorno/path-files",               "Rutas de Archivos",             Icons.Material.Filled.Folder,           typeof(PathFiles)),
        new("/entorno/postits",                 "Post-its",                      Icons.Material.Filled.PushPin,          typeof(PostItsBoard)),
        new("/entorno/notificaciones-consulta", "Notificaciones",                Icons.Material.Filled.Notifications,    typeof(NotificacionesConsulta)),
        new("/estandar/tipos-entidad",          "Tipos de Entidad",              Icons.Material.Filled.Category,         typeof(TiposEntidad)),
        new("/estandar/tipos-entidades",        "Tipos de Entidad",              Icons.Material.Filled.Category,         typeof(TiposEntidad)),
        new("/estandar/tipos-vias",             "Tipos de Vías",                 Icons.Material.Filled.Signpost,         typeof(TiposVias)),
        new("/estandar/tipos-via",              "Tipos de Vías",                 Icons.Material.Filled.Signpost,         typeof(TiposVias)),
        new("/estandar/tipos-documento-identidad", "Tipos Documento Identidad",  Icons.Material.Filled.Badge,            typeof(TipoDocumentoIdentidad)),
        new("/estandar/tipo-documento-identidad",  "Tipos Documento Identidad",  Icons.Material.Filled.Badge,            typeof(TipoDocumentoIdentidad)),
        new("/estandar/sexos",                  "Sexos",                         Icons.Material.Filled.People,           typeof(EstandarSexos)),
        new("/estandar/ubigeos",                "Ubigeos",                       Icons.Material.Filled.LocationOn,       typeof(EstandarUbigeos)),
        new("/estandar/paises",                 "Países",                        Icons.Material.Filled.Flag,             typeof(EstandarPaises)),
        new("/estandar/entidades",              "Entidades",      Icons.Material.Filled.Business,         typeof(EstandarEntidades)),
        new("/entidades",                       "Entidades",      Icons.Material.Filled.Business,         typeof(EstandarEntidades)),
        new("/estandar/tipos-producto",           "Tipos de Producto",               Icons.Material.Filled.Category,      typeof(TiposProducto)),
        new("/estandar/tiposproducto",            "Tipos de Producto",               Icons.Material.Filled.Category,      typeof(TiposProducto)),
        new("/estandar/grupos-producto",          "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/gruposproducto",           "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/grupos-productos",         "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/gruposproductos",          "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/familias-producto",        "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/familiasproducto",         "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/familias-productos",       "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/familiasproductos",        "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/sub-familias-producto",    "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/sub-familias-productos",   "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/subfamiliasproducto",      "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/subfamiliasproductos",     "Grupos de Producto",              Icons.Material.Filled.Folder,        typeof(GruposProducto)),
        new("/estandar/magnitudes",             "Magnitudes / Unidades de Medida", Icons.Material.Filled.Straighten,    typeof(Magnitudes)),
        new("/estandar/equivalencias",          "Equivalencias de Unidades",        Icons.Material.Filled.CompareArrows, typeof(Equivalencias)),
        new("/estandar/monedas",               "Monedas",        Icons.Material.Filled.AttachMoney,      typeof(EstandarMonedas)),
        new("/monedas",                         "Monedas",        Icons.Material.Filled.AttachMoney,      typeof(EstandarMonedas)),
        new("/estandar/monedas-tipo-cambio",   "Tipo de Cambio", Icons.Material.Filled.CurrencyExchange, typeof(EstandarMonedasTC)),
        new("/tipo-cambio",                     "Tipo de Cambio", Icons.Material.Filled.CurrencyExchange, typeof(EstandarMonedasTC)),
        new("/monedas-tipo-cambio",             "Tipo de Cambio", Icons.Material.Filled.CurrencyExchange, typeof(EstandarMonedasTC)),
        // Ingeniería
        new("/ingenieria/tipos-especificacion-tecnica",  "Tipos de Especificación Técnica", Icons.Material.Filled.Rule, typeof(TiposEspecificacionTecnica)),
        new("/ingenieria/tiposespecificaciontecnica",    "Tipos de Especificación Técnica", Icons.Material.Filled.Rule, typeof(TiposEspecificacionTecnica)),
        new("/ingenieria/especificaciones-tecnicas",     "Especificaciones Técnicas", Icons.Material.Filled.AccountTree, typeof(EspecificacionesTecnicas)),
        new("/ingenieria/especificacionestecnicas",      "Especificaciones Técnicas", Icons.Material.Filled.AccountTree, typeof(EspecificacionesTecnicas)),
        // Control de Calidad
        new("/controlcalidad/clases-defectos-tecnicos",  "Clases de Defectos Técnicos", Icons.Material.Filled.ReportProblem, typeof(ClasesDefectosTecnicos)),
        new("/controlcalidad/clasesdefectostecnicos",    "Clases de Defectos Técnicos", Icons.Material.Filled.ReportProblem, typeof(ClasesDefectosTecnicos)),
        new("/controlcalidad/tipos-defectos-tecnicos",   "Clases de Defectos Técnicos", Icons.Material.Filled.ReportProblem, typeof(ClasesDefectosTecnicos)),
        new("/controlcalidad/tiposdefectostecnicos",     "Clases de Defectos Técnicos", Icons.Material.Filled.ReportProblem, typeof(ClasesDefectosTecnicos)),
        new("/ingenieria/tipos-defecto-tecnico",          "Clases de Defectos Técnicos", Icons.Material.Filled.ReportProblem, typeof(ClasesDefectosTecnicos)),
        new("/ingenieria/tiposdefectotecnico",            "Clases de Defectos Técnicos", Icons.Material.Filled.ReportProblem, typeof(ClasesDefectosTecnicos)),
        // Comercial
        new("/comercial/tipos-precio",           "Tipos de Precio",        Icons.Material.Filled.Sell,             typeof(TiposPrecio)),
        new("/comercial/tipos-pedido-comercial", "Tipos de Pedido Comercial", Icons.Material.Filled.ShoppingCart,  typeof(TiposPedidoComercial)),
        new("/comercial/condiciones-pago",       "Condiciones de Pago",    Icons.Material.Filled.CreditScore,      typeof(CondicionesPago)),
        new("/comercial/formas-pago",            "Formas de Pago",         Icons.Material.Filled.Payments,         typeof(FormasPago)),
        new("/comercial/tipos-transporte",       "Tipos de Transporte",    Icons.Material.Filled.LocalShipping,    typeof(ComercialTiposTransporte)),
        new("/comercial/fases-incoterm",         "Fases de Incoterm",      Icons.Material.Filled.Timeline,         typeof(FasesIncoterm)),
        new("/comercial/tipos-descuento",        "Tipos de Descuento",     Icons.Material.Filled.Discount,         typeof(TiposDescuento)),
        new("/comercial/incoterms",              "Incoterms",              Icons.Material.Filled.Public,           typeof(Incoterms)),
        new("/comercial/tipos-pos",              "Tipos de POS",           Icons.Material.Filled.PointOfSale,       typeof(TiposPos)),
        new("/comercial/tipos-impuesto",         "Tipos de Impuesto",      Icons.Material.Filled.RequestQuote,      typeof(TiposImpuesto)),
        new("/comercial/tipos-medio-contacto",   "Tipos de Medio de Contacto", Icons.Material.Filled.ContactMail,   typeof(TiposMedioContacto)),
        new("/comercial/tipos-direccion",        "Tipos de Dirección",     Icons.Material.Filled.Home,              typeof(TiposDireccion)),
        new("/estandar/tipos-sucursales",        "Tipos de Sucursales",    Icons.Material.Filled.Storefront,        typeof(KONSolutions.Web.Pages.Estandar.TiposSucursales)),
        new("/estandar/sucursales",              "Sucursales",             Icons.Material.Filled.Business,          typeof(KONSolutions.Web.Pages.Estandar.Sucursales)),

        // Sistema
        new("/sistema/dashboard-monitoreo-bd",   "Monitoreo de BD",        Icons.Material.Filled.Storage,          typeof(KONSolutions.Web.Pages.Sistema.DashboardMonitoreoBD)),
        new("/developer/logviewer",              "Log de Errores",         Icons.Material.Filled.BugReport,        typeof(LogViewer)),
        new("/developer/log-viewer",             "Log de Errores",         Icons.Material.Filled.BugReport,        typeof(LogViewer)),
        new("/developer/disenador-pantallas",    "Diseñador de Pantallas", Icons.Material.Filled.DesignServices,   typeof(DisenadorPantallas)),
        new("/developer/pantalla-dinamica",      "Pantalla Dinámica",      Icons.Material.Filled.DynamicForm,      typeof(PantallaDinamica)),
        new("/seguridad/configuracion",          "Configuración",          Icons.Material.Filled.Settings,         typeof(Configuracion)),
        new("/seguridad/registro-facial-seguridad", "Registro Facial", Icons.Material.Filled.FaceRetouchingNatural, typeof(RegistroFacialSeguridad)),
        // Externo
        new("/externo/snippets",   "Snippets",  Icons.Material.Filled.Code,  typeof(Snippets)),
        new("/estandar/snippets",  "Snippets",  Icons.Material.Filled.Code,  typeof(Snippets)),
        // Menú circular
        new("/menu-circular", "Menú Circular", Icons.Material.Filled.DonutLarge, typeof(MenuCircularPage)),
        // Menú de tiles
        new("/menu-tiles", "Menú de Tiles", Icons.Material.Filled.GridView, typeof(KONSolutions.Web.Pages.MenuTilesPage)),
    };

    /// <summary>
    /// Normaliza DES_FORMULARIO a una ruta web comparable. El valor real en BD tiene
    /// el formato "Seguridad/Usuarios.razor" (carpeta + nombre de componente, con
    /// mayúsculas y extensión) — se convierte a "/seguridad/usuarios" antes de comparar.
    /// También tolera que ya venga como ruta web (con barra inicial, sin extensión).
    /// </summary>
    public static string Normalizar(string ruta)
    {
        var r = (ruta ?? "").Trim();
        if (r.EndsWith(".razor", StringComparison.OrdinalIgnoreCase))
            r = r[..^".razor".Length];
        // Convierte cada segmento de PascalCase a kebab-case antes de lowercase
        // p.ej. "BotonesEstandar" → "botones-estandar"
        r = string.Join("/", r.Replace('\\', '/').Split('/').Select(PascalToKebab));
        if (!r.StartsWith("/")) r = "/" + r;
        return r.TrimEnd('/');
    }

    private static string PascalToKebab(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < s.Length; i++)
        {
            if (i > 0 && char.IsUpper(s[i]) && !char.IsUpper(s[i - 1]))
                sb.Append('-');
            sb.Append(char.ToLowerInvariant(s[i]));
        }
        return sb.ToString();
    }

    public static PantallaInfo? PorRuta(string ruta)
        => Pantallas.FirstOrDefault(p => Normalizar(p.Ruta).Equals(Normalizar(ruta), StringComparison.OrdinalIgnoreCase));
}
