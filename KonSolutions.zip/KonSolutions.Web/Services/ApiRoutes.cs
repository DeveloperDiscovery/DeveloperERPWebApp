namespace KONSolutions.Web.Services;

/// <summary>
/// Rutas centralizadas de la API.
/// </summary>
public static class ApiRoutes
{
    public const string Prefix = "api/v1";

    public static class Auth
    {
        public const string Login = $"{Prefix}/auth/login";
    }

    public static class Entorno
    {
        public const string ControlCambios  = $"{Prefix}/entorno/control-cambios";
        public const string LimitesColumnas = $"{Prefix}/entorno/limites-columnas";
        public const string TiposNotificacion = $"{Prefix}/entorno/tipos-notificacion";
        public const string NotificacionesFlujoPendientes = $"{Prefix}/entorno/notificaciones-flujo/pendientes";
        public const string NotificacionesFlujoShowall    = $"{Prefix}/entorno/notificaciones-flujo/showall";
        public const string NotificacionesAprobaciones = $"{Prefix}/entorno/notificaciones-aprobaciones";
        public const string Servidores = $"{Prefix}/entorno/servidores";
        public const string PathFiles  = $"{Prefix}/entorno/pathfiles";
        public const string PostIts    = $"{Prefix}/entorno/postits";
        public const string DashboardBd = $"{Prefix}/entorno/dashboard-bd";
    }

    public static class Seguridad
    {
        public const string Usuarios              = $"{Prefix}/seguridad/usuarios";
        public const string UsuariosCombobox      = $"{Prefix}/seguridad/usuarios/combobox";
        public const string BotonesEstandar       = $"{Prefix}/seguridad/botones-estandar";
        public const string RolesUsuarioUsuarios  = $"{Prefix}/seguridad/roles-usuario-usuarios";
        public const string MisRoles              = $"{Prefix}/seguridad/roles-usuario-usuarios/mis-roles";
        public const string RolesUsuariosAplicacionesOpcionesBotones = $"{Prefix}/seguridad/roles-usuarios-aplicaciones-opciones-botones";
        public const string BotonesTreeview       = $"{Prefix}/seguridad/roles-usuarios-aplicaciones-opciones-botones/treeview";
        public const string UsuariosFavoritos     = $"{Prefix}/seguridad/usuarios-favoritos";
        public const string Favoritos             = $"{Prefix}/seguridad/favoritos";
        public const string FavoritosWorkspace    = $"{Prefix}/seguridad/favoritos/workspace";
        public const string EstadosPorTabla       = $"{Prefix}/seguridad/estados-por-tabla";
        public const string UsuariosSearch        = $"{Usuarios}/search";
        public const string UsuariosPassword      = $"{Usuarios}/password";
        public const string UsuariosPasswordReset = $"{Usuarios}/password-reset";
        public const string UsuariosEstados       = $"{Usuarios}/estados";
        public const string UsuariosResetIntentos = $"{Usuarios}/resetintentos";
        public const string PerfilesCombobox      = $"{Prefix}/seguridad/perfiles-usuario/combobox";
        public const string Perfiles              = $"{Prefix}/seguridad/perfiles-usuario";
        public const string Roles                 = $"{Prefix}/seguridad/roles-usuario";
        public const string ComplejidadPassword   = $"{Prefix}/seguridad/complejidad-password";
        public const string Aplicaciones          = $"{Prefix}/seguridad/aplicaciones";
        public const string RolesCombobox               = $"{Roles}/combobox";
        public const string ComplejidadPasswordCombobox = $"{ComplejidadPassword}/combobox";
        public const string AplicacionesCombobox        = $"{Aplicaciones}/combobox";
        public const string AplicacionesOpcionesTreeview = $"{Prefix}/seguridad/aplicaciones-opciones-treeview";
        public const string Opciones       = $"{Prefix}/seguridad/roles-usuarios-aplicaciones-opciones";
        public const string OpcionesPorRol = $"{Prefix}/seguridad/roles-usuarios-aplicaciones-opciones/por-rol";
        public const string Botones        = $"{Prefix}/seguridad/roles-usuarios-aplicaciones-opciones-botones";
        public const string AplicacionesOpcionesBotones = $"{Prefix}/seguridad/aplicaciones-opciones-botones";
        public const string AsignacionRoles    = $"{Prefix}/seguridad/usuario-asignaciones/roles-de-usuario";
        public const string AsignacionOpciones = $"{Prefix}/seguridad/usuario-asignaciones/opciones";
        public const string AsignacionBotones  = $"{Prefix}/seguridad/usuario-asignaciones/botones";
        public const string TiposOpciones        = $"{Prefix}/seguridad/tipos-opciones";
        public const string TiposOpcionesCombobox = $"{Prefix}/seguridad/tipos-opciones/combobox";
        public const string AplicacionesOpciones  = $"{Prefix}/seguridad/aplicaciones-opciones";
        public const string OpcionesTreeviewAsignadas   = $"{Opciones}/treeview-asignadas";
        public const string OpcionesTreeviewDisponibles = $"{Opciones}/treeview-disponibles";
    }

    public static class Estandar
    {
        public const string TiposSucursales         = $"{Prefix}/estandar/tipos-sucursales";
        public const string TiposSucursalesCombobox = $"{TiposSucursales}/combobox";
        public const string Sucursales              = $"{Prefix}/estandar/sucursales";
        public const string SucursalesCombobox      = $"{Sucursales}/combobox";
        public const string EstadosCombobox       = $"{Prefix}/estandar/estados/combobox";
        public const string TiposEstados          = $"{Prefix}/estandar/tipos-estados";
        public const string TiposEstadosCombobox  = $"{TiposEstados}/combobox";
        public const string Estados               = $"{Prefix}/estandar/estados";
        public const string EstadosPorTipo        = $"{Estados}/por-tipo";
        public const string EstadosImportEstandar = $"{Estados}/import-estandar";
        public const string EstadosEstandar       = $"{Prefix}/estandar/estados-estandar";
        public const string TiposMotivosCombobox  = $"{Prefix}/estandar/tipos-motivos/combobox";
        public const string TiposMotivos          = $"{Prefix}/estandar/tipos-motivos";
        public const string Motivos               = $"{Prefix}/estandar/motivos";
        public const string MotivosPorTipo        = $"{Motivos}/por-tipo";
        public const string TiposEntidades        = $"{Prefix}/estandar/tipos-entidades";
        public const string TiposEntidadesCombobox = $"{TiposEntidades}/combobox";
        public const string TiposVia              = $"{Prefix}/estandar/tipos-via";
        public const string Sexos                 = $"{Prefix}/estandar/sexos";
        public const string TiposUnidadMedida               = $"{Prefix}/estandar/tipos-unidad-medida";
        public const string TiposUnidadMedidaCombobox       = $"{TiposUnidadMedida}/combobox";
        public const string UnidadesMedida                  = $"{Prefix}/estandar/unidades-medida";
        public const string UnidadesMedidaCombobox          = $"{UnidadesMedida}/combobox";
        public const string UnidadesMedidaDownloadSnippet       = $"{UnidadesMedida}/download-from-snippet";
        public const string UnidadesMedidaEquivalencias              = $"{Prefix}/estandar/unidades-medida-equivalencias";
        public const string UnidadesMedidaEquivalenciasPorTipo       = $"{UnidadesMedidaEquivalencias}/por-tipo";
        public const string UnidadesMedidaEquivalenciasUpsert        = $"{UnidadesMedidaEquivalencias}/upsert";
        public const string UnidadesMedidaEquivalenciasCargarEstandar= $"{UnidadesMedidaEquivalencias}/cargar-estandar";
        public const string TiposDocumentoIdentidad         = $"{Prefix}/estandar/tipos-documento-identidad";
        public const string TiposDocumentoIdentidadCombobox = $"{TiposDocumentoIdentidad}/combobox";
        public const string PaisesCombobox                  = $"{Paises}/combobox";
        public const string Ubigeos                    = $"{Prefix}/estandar/ubigeos";
        public const string UbigeosCombobox            = $"{Ubigeos}/combobox";
        public const string UbigeosDownloadFromSnippet = $"{Ubigeos}/download-from-snippet";
        public const string TiposEmpresa               = $"{Prefix}/estandar/tipos-empresa";
        public const string TiposEmpresaCombobox       = $"{TiposEmpresa}/combobox";
        public const string Paises                     = $"{Prefix}/estandar/paises";
        public const string PaisesDownloadFromSnippet  = $"{Paises}/download-from-snippet";
        public const string PaisesDownloadStatus       = $"{Paises}/flag-download-status";
        public const string TiposProducto              = $"{Prefix}/estandar/tipos-producto";
        public const string TiposProductoCombobox      = $"{TiposProducto}/combobox";
        public const string GruposProducto               = $"{Prefix}/estandar/grupos-producto";
        public const string GruposProductoCombobox       = $"{GruposProducto}/combobox";
        public const string GruposProductoLoadcombos     = $"{GruposProducto}/loadcombos";
        public const string FamiliasProducto             = $"{Prefix}/estandar/familias-producto";
        public const string FamiliasProductoCombobox     = $"{FamiliasProducto}/combobox";
        public const string FamiliasProductoLoadcombos   = $"{FamiliasProducto}/loadcombos";
        public const string SubFamiliasProducto          = $"{Prefix}/estandar/sub-familias-producto";
        public const string SubFamiliasProductoLoadcombos = $"{SubFamiliasProducto}/loadcombos";
        public const string Entidades                  = $"{Prefix}/estandar/entidades";
        public const string EntidadesCombobox          = $"{Entidades}/combobox";
        public const string Monedas                    = $"{Prefix}/estandar/monedas";
        public const string MonedasCombobox            = $"{Prefix}/estandar/monedas/combobox";
        public const string MonedasTipoCambio          = $"{Prefix}/estandar/monedas-tipo-cambio";
        public const string ConfiguracionUsuario           = $"{Prefix}/estandar/configuracion-usuario";
        public const string ConfiguracionUsuarioMia        = $"{ConfiguracionUsuario}/mi-configuracion";
        public const string TiposMenuOpciones              = $"{Prefix}/estandar/tipos-menu-opciones";
        public const string TiposMenuOpcionesCombobox      = $"{TiposMenuOpciones}/combobox";
    }

    public static class Comercial
    {
        public const string TiposPrecio                  = $"{Prefix}/comercial/tipos-precio";
        public const string TiposPrecioCombobox          = $"{TiposPrecio}/combobox";
        public const string TiposPedidoComercial         = $"{Prefix}/comercial/tipos-pedido-comercial";
        public const string TiposPedidoComercialCombobox = $"{TiposPedidoComercial}/combobox";
        public const string CondicionesPago              = $"{Prefix}/comercial/condiciones-pago";
        public const string CondicionesPagoCombobox      = $"{CondicionesPago}/combobox";
        public const string FormasPago                   = $"{Prefix}/comercial/formas-pago";
        public const string FormasPagoCombobox           = $"{FormasPago}/combobox";
        public const string TiposTransporte              = $"{Prefix}/comercial/tipos-transporte";
        public const string TiposTransporteCombobox      = $"{TiposTransporte}/combobox";
        public const string FasesIncoterm                = $"{Prefix}/comercial/fases-incoterm";
        public const string FasesIncotermCombobox        = $"{FasesIncoterm}/combobox";
        public const string TiposDescuento               = $"{Prefix}/comercial/tipos-descuento";
        public const string TiposDescuentoCombobox       = $"{TiposDescuento}/combobox";
        public const string Incoterms                    = $"{Prefix}/comercial/incoterms";
        public const string IncotermsCombobox            = $"{Incoterms}/combobox";
        public const string IncotermsFases                    = $"{Prefix}/comercial/incoterms-fases";
        public const string IncotermsTiposTransporte          = $"{Prefix}/comercial/incoterms-tipos-transporte";
        public const string TiposPos                  = $"{Prefix}/comercial/tipos-pos";
        public const string TiposPosCombobox          = $"{TiposPos}/combobox";
        public const string TiposImpuesto             = $"{Prefix}/comercial/tipos-impuesto";
        public const string TiposImpuestoCombobox     = $"{TiposImpuesto}/combobox";
        public const string TiposImpuestoValores      = $"{Prefix}/comercial/tipos-impuesto-valores";
        public const string TiposMedioContacto        = $"{Prefix}/comercial/tipos-medio-contacto";
        public const string TiposMedioContactoCombobox = $"{TiposMedioContacto}/combobox";
        public const string TiposDireccion            = $"{Prefix}/comercial/tipos-direccion";
        public const string TiposDireccionCombobox    = $"{TiposDireccion}/combobox";
    }

    public static class Ingenieria
    {
        public const string TiposEspecificacionTecnica         = $"{Prefix}/ingenieria/tipos-especificacion-tecnica";
        public const string TiposEspecificacionTecnicaCombobox = $"{TiposEspecificacionTecnica}/combobox";
        public const string EspecificacionesTecnicas            = $"{Prefix}/ingenieria/especificaciones-tecnicas";
        public const string EspecificacionesTecnicasCombobox    = $"{EspecificacionesTecnicas}/combobox";
        public const string EspecificacionesTecnicasLoadcombos  = $"{EspecificacionesTecnicas}/loadcombos";
    }

    public static class Controlcalidad
    {
        public const string ClasesDefectosTecnicos         = $"{Prefix}/controlcalidad/clases-defectos-tecnicos";
        public const string ClasesDefectosTecnicosCombobox = $"{ClasesDefectosTecnicos}/combobox";
        public const string TiposDefectosTecnicos          = $"{Prefix}/controlcalidad/tipos-defectos-tecnicos";
        public const string TiposDefectosTecnicosCombobox  = $"{TiposDefectosTecnicos}/combobox";
    }

    public static class Biometria
    {
        public const string Base      = $"{Prefix}/biometria";
        public const string Estados   = $"{Base}/estados";
        public const string Estado    = $"{Base}/estado";
        public const string Registrar = $"{Base}/registrar";
        public const string Verificar = $"{Base}/verificar";
    }

    public static class Externo
    {
        public const string Snippets = $"{Prefix}/externo/snippets";
    }

    public static class Developer
    {
        public const string ErrorLog         = $"{Prefix}/developer/error-log";
        public const string AccessLog        = $"{Prefix}/developer/access-log";
        public const string Logs             = $"{Prefix}/developer/logs";
        public const string MetadataTablas   = $"{Prefix}/developer/metadata/tablas";
        public const string MetadataColumnas = $"{Prefix}/developer/metadata/columnas";
        public const string MetadataGuardar  = $"{Prefix}/developer/metadata/guardar";
        public const string MetadataBase     = $"{Prefix}/developer/metadata";
        public const string DatosBase        = $"{Prefix}/developer/data";
    }
}
