using System.Net.Http.Json;
using KONSolutions.Shared.Common;
using KONSolutions.Shared.Models.Entorno;

namespace KONSolutions.Web.Services;

/// <summary>
/// Cliente del Dashboard de Monitoreo de BD. Cada método pega a un endpoint del
/// DashboardBdController, que a su vez ejecuta un SP PROC_ENTORNO_DASHBOARD_BD_*.
/// El trace se sirve del buffer en memoria del API (no pega a la BD).
/// </summary>
public class DashboardBdService
{
    private readonly HttpClient _http;
    public DashboardBdService(HttpClient http) => _http = http;

    private string Base => ApiRoutes.Entorno.DashboardBd;

    private async Task<T?> GetUno<T>(string path)
    {
        try { return (await _http.GetFromJsonAsync<ApiResponse<T>>($"{Base}/{path}"))!.Data; }
        catch { return default; }
    }

    private async Task<List<T>> GetLista<T>(string path)
    {
        try { return (await _http.GetFromJsonAsync<ApiResponse<List<T>>>($"{Base}/{path}"))?.Data ?? new(); }
        catch { return new(); }
    }

    public Task<DashboardBdResumen?>            GetResumenAsync()        => GetUno<DashboardBdResumen>("resumen");
    public Task<List<DashboardBdSesion>>        GetSesionesAsync()       => GetLista<DashboardBdSesion>("sesiones");
    public Task<List<DashboardBdBloqueo>>       GetBloqueosAsync()       => GetLista<DashboardBdBloqueo>("bloqueos");
    public Task<List<DashboardBdConsulta>>      GetConsultasAsync(int top = 20) => GetLista<DashboardBdConsulta>($"consultas?top={top}");
    public Task<List<DashboardBdWait>>          GetWaitsAsync(int top = 15)     => GetLista<DashboardBdWait>($"waits?top={top}");
    public Task<List<DashboardBdTabla>>         GetTablasAsync(int top = 30)    => GetLista<DashboardBdTabla>($"tablas?top={top}");
    public Task<List<DashboardBdFragmentacion>> GetFragmentacionAsync()  => GetLista<DashboardBdFragmentacion>("fragmentacion");
    public Task<List<DashboardBdIndiceFaltante>>GetIndicesFaltantesAsync(int top = 20) => GetLista<DashboardBdIndiceFaltante>($"indices-faltantes?top={top}");
    public Task<List<DashboardBdArchivo>>       GetArchivosAsync()       => GetLista<DashboardBdArchivo>("archivos");
    public Task<List<DashboardBdBackup>>        GetBackupsAsync()        => GetLista<DashboardBdBackup>("backups");
    public Task<DashboardBdMemoria?>            GetMemoriaAsync()        => GetUno<DashboardBdMemoria>("memoria");
    public Task<List<DashboardBdIoLatencia>>    GetIoLatenciaAsync()     => GetLista<DashboardBdIoLatencia>("io-latencia");
    public Task<List<DashboardBdProcedimiento>> GetProcedimientosAsync(int top = 20) => GetLista<DashboardBdProcedimiento>($"procedimientos?top={top}");
    public Task<List<SpTraceEntry>>             GetTraceAsync(int top = 200)    => GetLista<SpTraceEntry>($"trace?top={top}");

    /// <summary>CHECKPOINT + SHRINKFILE del log. Devuelve MB antes/después o null si falló.</summary>
    public async Task<DashboardBdLimpiezaLog?> LimpiarLogAsync(int objetivoMb = 512)
        => await Post<DashboardBdLimpiezaLog>($"limpiar-log?objetivoMb={objetivoMb}");

    /// <summary>Genera un backup FULL/DIF/LOG en la carpeta por defecto de la instancia.</summary>
    public async Task<DashboardBdBackupResultado?> GenerarBackupAsync(string tipo = "FULL")
        => await Post<DashboardBdBackupResultado>($"backup?tipo={tipo}");

    /// <summary>KILL de la sesión indicada (el SP protege sesiones de sistema).</summary>
    public async Task<DashboardBdKillResultado?> KillSesionAsync(int numSesion)
        => await Post<DashboardBdKillResultado>($"kill-sesion?numSesion={numSesion}");

    private async Task<T?> Post<T>(string pathQuery)
    {
        try
        {
            var resp = await _http.PostAsync($"{Base}/{pathQuery}", null);
            if (!resp.IsSuccessStatusCode) return default;
            var r = await resp.Content.ReadFromJsonAsync<ApiResponse<T>>();
            return r is not null ? r.Data : default;
        }
        catch { return default; }
    }
}
