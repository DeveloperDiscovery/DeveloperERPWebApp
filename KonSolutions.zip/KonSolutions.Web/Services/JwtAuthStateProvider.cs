using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Components.Authorization;
using Blazored.LocalStorage;
using Microsoft.JSInterop;

namespace KONSolutions.Web.Services;

// FIX SEGURIDAD (Vuln 4): el token JWT se almacena en sessionStorage en lugar de
// localStorage. sessionStorage no persiste entre sesiones de navegador (se borra al
// cerrar la pestaña) y no es compartida entre pestañas, reduciendo la ventana de
// exposición ante extensiones maliciosas o XSS persistente.
// Los datos de sesión NO sensibles (usuarioSesion) siguen en localStorage para UX.
public class JwtAuthStateProvider : AuthenticationStateProvider
{
    private readonly ILocalStorageService _localStorage;
    private readonly IJSRuntime _js;
    private static readonly AuthenticationState Anonymous =
        new(new ClaimsPrincipal(new ClaimsIdentity()));

    public JwtAuthStateProvider(ILocalStorageService localStorage, IJSRuntime js)
    { _localStorage = localStorage; _js = js; }

    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        string? token;
        try { token = await _localStorage.GetItemAsync<string>("authToken"); }
        catch { return Anonymous; }

        if (string.IsNullOrWhiteSpace(token)) return Anonymous;

        var claims = ParseClaims(token).ToList();
        var exp = claims.FirstOrDefault(c => c.Type == "exp")?.Value;
        if (exp is not null && long.TryParse(exp, out var s))
        {
            if (DateTimeOffset.FromUnixTimeSeconds(s) < DateTimeOffset.UtcNow)
            {
                await _localStorage.RemoveItemAsync("authToken");
                await _localStorage.RemoveItemAsync("usuarioSesion");
                return Anonymous;
            }
        }
        return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity(claims, "jwt")));
    }

    public void NotifyUserAuthentication(string token)
        => NotifyAuthenticationStateChanged(Task.FromResult(
            new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity(ParseClaims(token), "jwt")))));

    public void NotifyUserLogout()
        => NotifyAuthenticationStateChanged(Task.FromResult(Anonymous));

    private static IEnumerable<Claim> ParseClaims(string token)
    {
        var payload = token.Split('.')[1];
        var json = Base64UrlDecode(payload);
        var dict = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(json);
        return dict is null ? Enumerable.Empty<Claim>()
            : dict.Select(kvp => new Claim(kvp.Key, kvp.Value.ToString()));
    }

    private static string Base64UrlDecode(string input)
    {
        var o = input.Replace('-', '+').Replace('_', '/');
        switch (o.Length % 4) { case 2: o += "=="; break; case 3: o += "="; break; }
        return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(o));
    }
}
