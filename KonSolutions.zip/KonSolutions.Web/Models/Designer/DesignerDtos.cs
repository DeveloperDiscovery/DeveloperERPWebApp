namespace KONSolutions.Web.Models.Designer;

/// <summary>
/// Mapea el NodoOpcion que devuelve GET api/v1/seguridad/aplicaciones-opciones-treeview.
/// Solo se usan nodos de tipo BTN (hojas reales con pantalla asociada).
/// </summary>
public class OpcionAplicacionDto
{
    public string  COD_APLICACION_ORIGINAL { get; set; } = "";
    public string  COD_OPCION_ORIGINAL     { get; set; } = "";
    public string  DES_OPCION             { get; set; } = "";
    public string  COD_TIPO               { get; set; } = "";
    public string  DES_PAGINA             { get; set; } = "";
}

public class ColumnaDbDto
{
    public string NombreColumna { get; set; } = "";
    public string? TipoDato     { get; set; }
    public bool   EsNullable    { get; set; }
    public int?   MaxLength     { get; set; }
}

public class CampoPKDto
{
    public string NombreCampo { get; set; } = "";
    public int    Orden       { get; set; }
}

public class ColumnaGrillaDto
{
    public string NombreCampo   { get; set; } = "";
    public string Etiqueta      { get; set; } = "";
    public string? CampoMostrar { get; set; }
    public int    Orden         { get; set; }
    public bool   EsFiltrable   { get; set; } = true;
    public bool   EsOrdenable   { get; set; } = true;
}

public class CampoFormularioDto
{
    public string  NombreCampo   { get; set; } = "";
    public string  Etiqueta      { get; set; } = "";
    public string  TipoInput     { get; set; } = "TEXTO";
    public int     Orden         { get; set; }
    public bool    EsObligatorio { get; set; }
    public bool    EsSoloLectura { get; set; }
    public string? TablaCombo    { get; set; }
    public int?    LongitudMax   { get; set; }
}

public class RelacionDto
{
    public string CampoPadre { get; set; } = "";
    public string CampoHijo  { get; set; } = "";
}

public class NivelGrillaDto
{
    public Guid   Id             { get; set; } = Guid.NewGuid();
    public Guid?  NivelPadreId   { get; set; }
    public int    Profundidad    { get; set; }
    public string Schema         { get; set; } = "ESTANDAR";
    public string NombreTabla    { get; set; } = "";
    public string TituloGrilla   { get; set; } = "";
    public string TipoPantalla   { get; set; } = "GRILLA_FORM";
    public int    FilasPorPagina { get; set; } = 10;

    public List<ColumnaDbDto>        Columnas         { get; set; } = new();
    public List<CampoPKDto>          CamposPK         { get; set; } = new();
    public List<ColumnaGrillaDto>    ColumnasGrilla   { get; set; } = new();
    public List<CampoFormularioDto>  CamposFormulario { get; set; } = new();
    public List<RelacionDto>         Relaciones       { get; set; } = new();
}
