namespace KONSolutions.Web.Models.Developer;

public class PantallaMetadataDto
{
    public string CodAplicacion { get; set; } = "";
    public string CodOpcion     { get; set; } = "";
    public List<NivelMetadataDto> Niveles { get; set; } = new();
}

public class NivelMetadataDto
{
    public int    NumNivel       { get; set; }
    public string Titulo         { get; set; } = "";
    public string Tabla          { get; set; } = "";
    public string Schema         { get; set; } = "";

    public List<ClavePKDto>         Claves           { get; set; } = new();
    public List<ColumnaGrillaDto>   ColumnasGrilla   { get; set; } = new();
    public List<CampoFormularioDto> CamposFormulario { get; set; } = new();
}

public class ClavePKDto
{
    public string Campo { get; set; } = "";
    public int    Orden { get; set; }
}

public class ColumnaGrillaDto
{
    public string  Campo         { get; set; } = "";
    public string  Etiqueta      { get; set; } = "";
    public int     Orden         { get; set; }
    public bool    EsFiltrable   { get; set; }
    public bool    EsOrdenable   { get; set; }
    public string? CampoMostrar  { get; set; }
}

public class CampoFormularioDto
{
    public string  Campo         { get; set; } = "";
    public string  Etiqueta      { get; set; } = "";
    public string  TipoControl   { get; set; } = "TEXTO";
    public int     Orden         { get; set; }
    public bool    EsObligatorio { get; set; }
    public bool    EsSoloLectura { get; set; }
    public string? TablaCombo    { get; set; }
    public int?    LongitudMax   { get; set; }
}

public class DataPageResultDto
{
    public List<Dictionary<string, object?>> Rows  { get; set; } = new();
    public int                               Total { get; set; }
}
