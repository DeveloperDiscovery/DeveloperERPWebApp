using System.ComponentModel.DataAnnotations;
namespace KONSolutions.Shared.Models.Comercial;

/// <summary>Entidad TIPOS_PEDIDO_COMERCIAL - tipos equivalentes a la BD.</summary>
public class TiposPedidoComercial
{
    public int? COD_TIPO_PEDIDO_COMERCIAL { get; set; }
    public string DES_TIPO_PEDIDO_COMERCIAL { get; set; } = string.Empty;
    public string COD_TIPO_ENTIDAD { get; set; } = string.Empty;
    public string COD_TIPO_ENTIDAD_VENDEDORA { get; set; } = string.Empty;
    public int? COD_TIPO_ESTADO { get; set; }
    public bool? FLG_PEDIDO_FORMAL { get; set; }
    public bool? FLG_BIENES { get; set; }

    // Solo lectura (vienen del JOIN en SHOWALL/SEARCH/SHOWBYID).
    public string? DES_TIPO_ENTIDAD { get; set; }
    public string? DES_TIPO_ENTIDAD_VENDEDORA { get; set; }
    public string? DES_TIPO_ESTADO { get; set; }
}

public class TiposPedidoComercialInsertDto
{
    public int? COD_TIPO_PEDIDO_COMERCIAL { get; set; }
    [Required] public string DES_TIPO_PEDIDO_COMERCIAL { get; set; } = string.Empty;
    [Required] public string COD_TIPO_ENTIDAD { get; set; } = string.Empty;
    [Required] public string COD_TIPO_ENTIDAD_VENDEDORA { get; set; } = string.Empty;
    public int? COD_TIPO_ESTADO { get; set; }
    public bool? FLG_PEDIDO_FORMAL { get; set; }
    public bool? FLG_BIENES { get; set; }
}

public class TiposPedidoComercialUpdateDto
{
    public int? COD_TIPO_PEDIDO_COMERCIAL { get; set; }
    [Required] public string DES_TIPO_PEDIDO_COMERCIAL { get; set; } = string.Empty;
    [Required] public string COD_TIPO_ENTIDAD { get; set; } = string.Empty;
    [Required] public string COD_TIPO_ENTIDAD_VENDEDORA { get; set; } = string.Empty;
    public int? COD_TIPO_ESTADO { get; set; }
    public bool? FLG_PEDIDO_FORMAL { get; set; }
    public bool? FLG_BIENES { get; set; }
}

public class TiposPedidoComercialSearchDto
{
    public string? Search { get; set; }
}