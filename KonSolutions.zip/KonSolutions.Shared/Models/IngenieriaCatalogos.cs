using System.ComponentModel.DataAnnotations;
using KONSolutions.Shared.Common;

namespace KONSolutions.Shared.Models.Ingenieria;

// ───────────── INGENIERIA.TIPOS_ESPECIFICACION_TECNICA ─────────────
public class TiposEspecificacionTecnica
{
    [Required] public string COD_TIPO_ESPECIFICACION_TECNICA { get; set; } = "";
    [Required] public string DES_TIPO_ESPECIFICACION_TECNICA { get; set; } = "";
    public bool? FLG_LISTA               { get; set; }
    public bool? FLG_ENTERO              { get; set; }
    public bool? FLG_NUMERICO            { get; set; }
    public bool? FLG_CADENA              { get; set; }
    public bool? FLG_FECHA_HORA          { get; set; }
    public bool? FLG_FECHA               { get; set; }
    public bool? FLG_HORA                { get; set; }
    public bool? FLG_LOGICO              { get; set; }
    public bool? FLG_COLOR               { get; set; }
    public int?  NUM_ORDEN_PRESENTACION  { get; set; }
}

// ───────────── INGENIERIA.ESPECIFICACIONES_TECNICAS ─────────────
public class EspecificacionesTecnicas
{
    public long COD_ESPECIFIACION_TECNICA { get; set; }
    [Required] public string DES_ESPECIFIACION_TECNICA { get; set; } = "";
    [Required] public string DES_ESPECIFIACION_TECNICA_SINGULAR { get; set; } = "";
    public long? COD_ESPECIFIACION_TECNICA_PADRE { get; set; }
    [Required] public string COD_TIPO_ESPECIFICACION_TECNICA { get; set; } = "";
    public bool? FLG_LISTA                 { get; set; }
    public bool? FLG_ITEM_LISTA            { get; set; }
    public bool? FLG_DEPENDENCIA_ENTIDAD   { get; set; }
    public bool? FLG_SELECCION_MULTIPLE    { get; set; }
    public bool? FLG_ITEM_VALOR            { get; set; }
    public bool? FLG_DEFAULT               { get; set; }
    public bool? FLG_ENSAMBLAJE_PRODUCTO   { get; set; }
    public bool? FLG_CONTROL_CALIDAD       { get; set; }
    public bool? FLG_OBSERVACION           { get; set; }
    public bool? FLG_RANGO                 { get; set; }
    public bool? FLG_EDITABLE_TOMA_PEDIDO  { get; set; }
    public string COD_CLASE_DEFECTO_TECNICO        { get; set; } = "";
    public string COD_TIPO_DEFECTO_TECNICO_DEFECTO { get; set; } = "";
    public decimal? COD_ENTIDAD            { get; set; }
    public string DES_PREFIJO              { get; set; } = "";
    public string DES_SUFIJO               { get; set; } = "";
    public int?  CAN_ENTERO                { get; set; }
    public int?  CAN_DECIMAL               { get; set; }
    public string COD_UNIDAD_MEDIDA        { get; set; } = "";
    public string COD_UNIDAD_MEDIDA_DIVISORA { get; set; } = "";
    public int?  NUM_ORDEN_PRESENTACION    { get; set; }
    public byte[]? IMG_ICONO               { get; set; }
    public int?  COD_TIPO_ESTADO           { get; set; }
    public int?  COD_ESTADO                { get; set; }
    public string DES_BACKCOLOR            { get; set; } = "";
    public string DES_ESTADO               { get; set; } = "";
    public string DES_FORECOLOR            { get; set; } = "";
    public string DES_CLASE_DEFECTO_TECNICO { get; set; } = "";
    public string DES_DEFECTO_TECNICO      { get; set; } = "";
    public string DES_UNIDAD_MEDIDA        { get; set; } = "";
    public string DES_ENTIDAD              { get; set; } = "";

    /// <summary>Nodos hijos — se arma en memoria a partir de COD_ESPECIFIACION_TECNICA_PADRE, no viene del API.</summary>
    public List<EspecificacionesTecnicas> Hijos { get; set; } = new();
}

public class EspecificacionesTecnicasLoadCombosResult
{
    public int                CodTipoEstado       { get; set; }
    public List<ComboboxItem> ClasesDefecto       { get; set; } = new();
    public List<ComboboxItem> TiposEspecificacion { get; set; } = new();
    public List<EstadoItem>   Estados             { get; set; } = new();
    public List<ComboboxItem> UnidadesMedida      { get; set; } = new();
    public List<ComboboxItem> Entidades           { get; set; } = new();
}
